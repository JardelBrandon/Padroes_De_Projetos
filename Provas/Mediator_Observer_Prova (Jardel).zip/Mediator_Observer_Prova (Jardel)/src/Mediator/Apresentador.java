/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mediator;

import Observer.Telespectador;
import Sujeito_Colaborador.Microfone;
import Sujeito_Colaborador.Candidato;
import java.util.ArrayList;
import java.util.Date;
import java.util.function.Consumer;
import javax.swing.JTextArea;

/**
 *
 * @author robotica
 */
public class Apresentador implements Mediador {
    private final ArrayList<Candidato> colaboradores;
    private String dados;
    private final JTextArea trasmissaoMediada;
    
    public Apresentador(JTextArea trasmissaoAoVivo) {
        colaboradores = new ArrayList<>();
        trasmissaoMediada = trasmissaoAoVivo;
        dados = "";
    }
    
    public void adicionarColaborador(Candidato colaborador) {
        colaboradores.add(colaborador);
    }
    
    public void removerColaborador(Candidato colaborador) {
        colaboradores.remove(colaborador);
    }
    
    public Candidato getColaborador(int i) {
        return colaboradores.get(i);
    }
    public ArrayList<Candidato> getColaboradores() {
        return colaboradores;
    }
    
    @Override
    public void liberarMicrofone(Microfone microfone) {
        
        microfone.setVisible(true); //Ligar Microfone do candidadato
        colaboradores.forEach((Candidato c) -> {
            if (c.getMicrofone() != microfone) {
                c.getMicrofone().setVisible(false);
            }
            else {
                c.getEleitores().forEach((e) -> {
                    e.atualizar();
                });
            }
        });
    }
    
    @Override
    public void desligarTodosMicrofones() {
        colaboradores.forEach((c) -> {
            //Desligar microfone dos outros candidatos
            c.getMicrofone().setVisible(false);
        });
    }
    
    @Override
    public void transmitirFala(Candidato candidato) {
        Date data = new Date();
        int horas = data.getHours();
        int minutos = data.getMinutes();
        int segundos = data.getSeconds();
        String trasmitir = "(" + String.valueOf(horas);
        trasmitir += ":" + String.valueOf(minutos);
        trasmitir += ":" + String.valueOf(segundos) + ") ";
        trasmitir += candidato.getNome();
        trasmitir += " : ";
        trasmitir += candidato.getDiscurso();
        dados += trasmitir;
        trasmissaoMediada.setText(dados);
        dados += "\n";
    }
}
