/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sujeito_Colaborador;

import Mediator.Mediador;
import Observer.Telespectador;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author robotica
 */
public abstract class Candidato {
    private final Mediador mediador;
    private final String nome;
    private final String numero;
    private String discurso;
    private final Microfone microfone;
    private final List<Telespectador> eleitores = new ArrayList();
    
    public Candidato(Mediador mediador, String nome, String numero) {
        this.mediador = mediador;
        this.nome = nome;
        this.numero = numero;
        this.microfone = new Microfone(this);
    }
    
    public void permissaoParaLigarMicrofone() {
        mediador.liberarMicrofone(this.microfone);
    }
    
    public void falar() {
        mediador.transmitirFala(this);
    }
    
    public void adicionar(Telespectador t) {
        eleitores.add(t);
    }
    
    public void remover(Telespectador t) {
        eleitores.remove(t);
    }

    public List<Telespectador> getEleitores() {
        return eleitores;
    }
    
    public String getNome() {
        return nome;
    }

    public String getNumero() {
        return numero;
    }

    public Microfone getMicrofone() {
        return microfone;
    }

    public void setDiscurso(String discurso) {
        this.discurso = discurso;
    }

    public String getDiscurso() {
        return discurso;
    }

    @Override
    public String toString() {
        return nome + " - (" + numero + ")" + "-" + this.getClass().getSimpleName();
    }
}
