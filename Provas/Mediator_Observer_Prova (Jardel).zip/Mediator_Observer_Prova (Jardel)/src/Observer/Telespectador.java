/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Observer;

import Sujeito_Colaborador.Candidato;
import java.util.Date;
import javax.swing.JTextArea;

/**
 *
 * @author jarde
 */
public class Telespectador implements Observador {
    private final String nome;
    private Candidato candidatoNotificacao;
    private static String notificacoes;
    private static JTextArea areaDeNotificacao;

    public Telespectador(String nome, JTextArea jta) {
        this.nome = nome;
        Telespectador.areaDeNotificacao = jta;
        notificacoes = "";
    }

    @Override
    public void atualizar() {
        String horas = String.valueOf(new Date().getHours());
        String minutos = String.valueOf(new Date().getMinutes());
        notificacoes += "Telespectador " + nome + ": SEU CANDIDATO ESTÁ FALANDO! ("
                + horas + ":" + minutos + ")\n";
        areaDeNotificacao.setText(notificacoes);
    }

    @Override
    public String toString() {
        return (candidatoNotificacao == null) ? "Telespectador: " + nome : 
                "Telespectador: " + nome + " -> Candidato: " + candidatoNotificacao.getNome();
    }

    public Candidato getCandidatoNotificacao() {
        return candidatoNotificacao;
    }

    public void setCandidatoNotificacao(Candidato candidatoNotificacao) {
        this.candidatoNotificacao = candidatoNotificacao;
    }

    public String getNome() {
        return nome;
    }
    
}
