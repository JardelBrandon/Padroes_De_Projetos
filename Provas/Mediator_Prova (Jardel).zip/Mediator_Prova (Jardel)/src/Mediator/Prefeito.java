/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mediator;


/**
 *
 * @author robotica
 */
public class Prefeito extends Candidato {

    public Prefeito(Mediador mediador, String nome, String numero) {
        super(mediador, nome, numero);
    }

}
