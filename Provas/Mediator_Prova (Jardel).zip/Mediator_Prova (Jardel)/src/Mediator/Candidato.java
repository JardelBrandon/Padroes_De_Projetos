/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mediator;

/**
 *
 * @author robotica
 */
public abstract class Candidato {
    private Mediador mediador;
    private final String nome;
    private final String numero;
    private String discurso;
    private Microfone microfone;

    public Candidato(Mediador mediador, String nome, String numero) {
        this.mediador = mediador;
        this.nome = nome;
        this.numero = numero;
        this.microfone = new Microfone(this);
    }
    
    public void permissaoParaLigarMicrofone() {
        mediador.liberarMicrofone(this.microfone);
    }
    
    public void falar() {
        mediador.transmitirFala(this);
    }
    
    public String getNome() {
        return nome;
    }

    public String getNumero() {
        return numero;
    }

    public Microfone getMicrofone() {
        return microfone;
    }

    public void setDiscurso(String discurso) {
        this.discurso = discurso;
    }

    public String getDiscurso() {
        return discurso;
    }
}
