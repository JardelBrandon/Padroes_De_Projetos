/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Observer;

/**
 *
 * @author jarde
 */
public class Main {

    /**
     * @param args the command line arguments
     */
        public static void main(String[] args) {
            Televisao trasmissaoAoVivo = new Televisao();
            
            Telespectador telespectador1 = new Telespectador(trasmissaoAoVivo, "João");
            Telespectador telespectador2 = new Telespectador(trasmissaoAoVivo, "José");
            Telespectador telespectador3 = new Telespectador(trasmissaoAoVivo, "Maria");
            Telespectador telespectador4 = new Telespectador(trasmissaoAoVivo, "Carlos");
            Telespectador telespectador5 = new Telespectador(trasmissaoAoVivo, "Aparecida");
            Telespectador telespectador6 = new Telespectador(trasmissaoAoVivo, "Ana");
        
            trasmissaoAoVivo.setDados("Hadad falou: Vou ser Presidente");
            
            trasmissaoAoVivo.setDados("Bolsonaro disse: 17");
    }
    
}
