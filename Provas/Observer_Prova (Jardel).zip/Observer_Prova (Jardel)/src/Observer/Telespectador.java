/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Observer;

/**
 *
 * @author jarde
 */
public class Telespectador implements Observador {
    private String dadosObservados;
    private Televisao sujeitoConcreto;
    private String nome;

    public Telespectador(Televisao tv, String nome) {
        this.sujeitoConcreto = tv;
        sujeitoConcreto.cadastrar(this);
        this.nome = nome;
    }

    @Override
    public void atualizar() {
        dadosObservados = sujeitoConcreto.getDados();
        System.out.println(this.toString() + ": SEU CANDIDATO ESTÁ FALANDO");
    }

    @Override
    public String toString() {
        return "Telespectador: " + nome;
    }
    
    
}
